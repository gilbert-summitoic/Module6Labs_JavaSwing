//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.awt.LayoutManager;
import javax.swing.JButton;
import javax.swing.JFrame;

public class SwingInheritanceExample extends JFrame {
    JFrame f;

    SwingInheritanceExample() {
        JButton b = new JButton("click");
        b.setBounds(130, 100, 100, 40);
        this.add(b);
        this.setSize(400, 500);
        this.setLayout((LayoutManager)null);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        new SwingInheritanceExample();
    }
}
