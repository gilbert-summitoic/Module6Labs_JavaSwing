import javax.swing.*;
public class FirstSwingExample {
    public static void main(String[] args) {
        JFrame f = new JFrame(); //create an instance of a JFrame.

        JButton b = new JButton("click"); //create an instance of the JButton
        b.setBounds(130,100,100, 40); // x, y, width, height

        f.add(b); //add button to frame

        f.setSize(400,500); //set frame size
        f.setLayout(null); //using no layer manager
        f.setVisible(true); //makes the frame visible
    } //end main method
} // end FirstSwingClass