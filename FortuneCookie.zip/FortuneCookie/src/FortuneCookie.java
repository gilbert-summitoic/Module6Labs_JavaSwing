import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.sql.DriverManager;

public class FortuneCookie {
    static String fortunes;

    public static void main(String[] args) {
            //create Fortune Cookie frame
            JFrame f = new JFrame("Fortune Cookie");
            f.setSize(500, 500); //set frame size
            f.setLayout(null); //set frame layout to null

            //create TextArea to display fortune message when button is clicked
            final JTextArea tArea = new JTextArea(); //use final modifier to prevent resizing
            tArea.setBounds(60, 150, 340, 80); //set text area dimensions
            tArea.setBackground(Color.lightGray); //make text area background lightgray

            //Create, allocate and style button
            JButton b = new JButton("Find Fortune");
            b.setBounds(150, 100, 120, 40);
            b.setBackground(Color.lightGray);

            //create image icon using recommended url "images/..."
            ImageIcon icon = new ImageIcon("images/cookie.jpg");
            JLabel imageLabel = new JLabel( icon, JLabel.CENTER); //parse image in new label
            imageLabel.setBounds(120, 210, 200, 200); //set dimensions of new label

            //set label visibility to true
            imageLabel.setVisible(true);

                //add action for button when clicked
                b.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
 /**
  * Scope random number, database access, and query within the button ActionListener to ensure continuous rs
  * pull as button is being clicked
  * */
                        //create a random number
                        double dr = Math.random() * 13;  //specify to limit out of bounds exception
                        int randomNumber = (int) dr;    //type cast randomNumber from double to int
                        if(randomNumber==0){ //prevent outcome of zero
                            randomNumber++;
                        }//End if randomNumber
                        try { //use try-catch to catch database error
                            Connection con = DriverManager.getConnection(
                                    "jdbc:mysql://localhost:3306/fortunes", "root", "admin");
                            Statement stmt = con.createStatement(); //create a statement
                            //Execute the statement and obtain a resultset
                            ResultSet rs = stmt.executeQuery("" +
                                    "SELECT id, fortuneMessage FROM fortuneTable WHERE id = " + randomNumber + ";");
                            while (rs.next()) {
                                fortunes = rs.getString(2); //message is passed to fortunes String
                                tArea.setText(fortunes + "\n"); //print rs to JTextArea in Frame f
                                System.out.println("Random Number: "+randomNumber+" >> \t"+fortunes); //also print rs to console
                            } // end while loop
                            con.close(); //close database connection
                        } catch (Exception ex) { //Catch exception and print Stacktrace
                            ex.printStackTrace();
                        } //end try-catch

                        }//End ActionEvent
                    });//end ActionListener

        //Add created components to frame
            f.add(b);
            f.add(tArea);
            f.add(imageLabel);
            f.setVisible(true);

    }//end psvm
}//end FortuneCookie class